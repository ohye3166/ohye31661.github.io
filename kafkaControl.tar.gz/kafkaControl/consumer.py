import log
import ssl
from kafka import KafkaConsumer
import time
context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
CONSUMER_CONF ={'sasl_mechanism': 'PLAIN', 'sasl_plain_username': 'nvwa', 'ssl_context':context, 'security_protocol': 'SASL_SSL', 'bootstrap_servers': ['162.129.101.54:9092'], 'sasl_plain_password': 'X1M7ylc59lPMNCN8PA+','auto_offset_reset': 'earliest'}
topic = 'czy'
consumer = KafkaConsumer(topic, **CONSUMER_CONF)
while True:
    msgs = consumer.poll()
    print('msgs = %s' % msgs)
    time.sleep(5)
