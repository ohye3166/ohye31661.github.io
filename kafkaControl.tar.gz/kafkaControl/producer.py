import ssl
import six
import json
from FSSecurity import crypt
from kafka import KafkaProducer

context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
with open('/etc/huawei/fusionsphere/kafka.kafka/cfg/kafka.kafka.cfg', 'r') as fd:
    data  = json.load(fd)
sasl_plain_password = crypt.decrypt(data['sasl_plain_password'])

PRODUCER_CONF = {'sasl_mechanism': 'PLAIN', 'security_protocol': 'SASL_SSL', 'acks': 1, 'retries': 5, 'sasl_plain_username': 'nvwa', 'bootstrap_servers': ['162.129.101.54:9092'], 'ssl_context': context, 'sasl_plain_password': sasl_plain_password}
producer = KafkaProducer(**PRODUCER_CONF)
num = 0
for i in range(10):
    msgs = 'message_' + str(num)
    num += 1
    producer.send('czy', six.ensure_binary(msgs), partition=0).get()
